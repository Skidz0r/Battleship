//                              ____        _   _   _           _     _
//                             |  _ \      | | | | | |         | |   (_)
//                             | |_) | __ _| |_| |_| | ___  ___| |__  _ _ __
//                             |  _ < / _` | __| __| |/ _ \/ __| '_ \| | '_ \
//                             | |_) | (_| | |_| |_| |  __/\__ \ | | | | |_) |
//                             |____/ \__,_|\__|\__|_|\___||___/_| |_|_| .__/
//                                                                     | |
//                                                                     |_|
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include "barcos.h"
int flag_random=0;
int maximo_pecas;
int contagem_random;
int tamanhocampo;
int player_flag=0;
int random_vec[13][2]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};    // guardar posiçoes para colocar barcos na maneira random

 struct barco {
  char *peca;
  char boat;
};

 struct cell {
  struct barco sh;                           // struct da estrutura da peca que vai conter a estrutura da peça
  int shot;                                             // valor do tiro
};


void delay()
{
    int mili_segundos = 1000 * 3000;               // 3000 = +/- 3 segundos
    clock_t comeco = clock();                      // obter hora local
    while (clock() < comeco + mili_segundos);
}

void preencher(int x, int y)
{
  int flag=0;
  for(int i=0;i<13;i++)
  {
      if(random_vec[i][0]==0 && random_vec[i][1]==0 && flag==0)
      {
        random_vec[i][0]=x;
        random_vec[i][1]=y;
        flag=1;
      }
  }
}

int contar_pecas(int tamanhocampo, struct cell jogo[tamanhocampo][tamanhocampo])
{
  int contagem=0;
  for(int i=0;i<tamanhocampo;i++)
  {
    for(int k=0;k<tamanhocampo;k++)
    {
      if(*jogo[i][k].sh.peca=='1')
      {
        contagem++;
      }
    }
  }
  return contagem;
}

void definir(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo] )
{
  for(int i=0;i<tamanhocampo;i++)
  {
    for(int k=0;k<tamanhocampo;k++)
    {
      jogo[i][k].sh.peca="0";
    }
  }
}

int aleatorio(int x , int y)   // x limite inferior , y limite superior
{
  int numero = (rand()%(y-x+1))+x; // dois numeros randoms
  return numero;
}

int alfabeto(char ch) // letra para numero
{
  int x=0;
  if(ch>='a' && ch<='z')
  {
    x= ch-'a'+26;
  }
  else if(ch>='A' && ch<='Z')
  {
    x=ch-'A';
  }
  return x;
}

char alfabeto_v2(int x) // numero para letra
{
  char ch;
  if(x<=25)
  ch=x+'A';
  if(x>25)
  {
  x=x-26;
  ch=x+'A';
  ch=tolower(ch);
}
  return ch;
}

int contagem_false(int x,int y)
{
  for(int i=0;i<13;i++)
  {
    if(random_vec[i][0]==x || random_vec[i][0]==x+1 || random_vec[i][0]==x-1 || random_vec[i][0]==x-2 || random_vec[i][0]==x+2 || random_vec[i][0]==x-3 || random_vec[i][0]==x+3)
    {
      if(y>=random_vec[i][1]-4 && y<=random_vec[i][1]+4)
      {
        return 0;
      }
    }
  }
  return 1;
}

void limpar_random()
{
  for(int i=0;i<13;i++)
  {
    random_vec[i][1]=0;
    random_vec[i][0]=0;
  }
}

void play_screen()
{
  system("clear");
  printf("\n\n");
  printf("  ______________________________________________   \n");
  printf(" |       Todas as peças foram colocadas         |  \n");
  printf(" |    O jogo irá começar em breves instantes    |  \n");
  printf(" |______________________________________________|  \n");
  delay();

}

void vencedor(int vencedor)
{
  system("clear");
  printf("\n\n");
  printf("  ______________________________________________   \n");
  printf(" |                   Parabens!                  |  \n");
  printf(" |          Jogador %d venceu o jogo!            |  \n",vencedor);
  printf(" |______________________________________________|  \n");
}

void printar_tabuleiro(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  system("clear");
  printf("\n");
  if(player_flag==0)
  {
    for(int i=0;i<(tamanhocampo+10)/2;i++)
    {
      printf("  ");
    }
    printf("PLAYER 1\n\n");
  }
  else if(player_flag==1)
  {
    for(int i=0;i<(tamanhocampo+10)/2;i++)
    {
      printf("  ");
    }
    printf("PLAYER 2\n\n");
  }
  int x=0;
  int n=1;
  char ch='A';
  int flag=0;
  for(int k=0;k<tamanhocampo;k++)   // Colocar alfabeto
  {
    if(ch>'Z' && flag==0)
    {
      ch+=6;                                                                     // ao colocar alfabeto, se passar do Z começar outra vez o alfabeto mas em minusculo
      flag=1;                                                                   /// flag para incrementar so 1 vez
    }
    if(k==0)
      {
        printf("    %c",ch);
      }
      else
      {
        printf("  %c",ch);
      }
      ch=(char)(ch+1);
  }
  printf("\n\n");
    for(int i=0;i<tamanhocampo;i++)
    {
      for(int k=0;k<tamanhocampo;k++)
      {
        if(k==0)
        {
          if(n>=10)
          {
            printf("%d ",n);
          }
          else if(n<10)
          {
          printf("%d  ",n);
        }
          n++;
        }
        if(*jogo[i][k].sh.peca=='0')
        {
          printf(" - ");
        }
        else if(*jogo[i][k].sh.peca=='1')
        {
            printf(" %c ",jogo[i][k].sh.boat);
        }
        else if(*jogo[i][k].sh.peca=='2')
        {
          printf(" x ");
        }
        else if(*jogo[i][k].sh.peca=='3' && jogo[i][k].shot==1)
        {
          printf(" + ");
        }
      }
      printf("\n");
    }

}
void barco_afundado(int tamanhocampo, struct cell jogo[tamanhocampo][tamanhocampo], char barco)
{
  int contagem=0;
  for(int i=0;i<tamanhocampo;i++)
  {
    for(int k=0;k<tamanhocampo;k++)
    {
      if(*jogo[i][k].sh.peca=='1' && jogo[i][k].sh.boat==barco)
      {
        contagem++;
      }
    }
  }
  if(contagem==0)
  {
        setvbuf(stdout, NULL, _IONBF, 0);
    switch(barco)
    {
      case 'S': printf("\nSubmarino afundado com sucesso!");break;
      case 'C': printf("\nCruiser afundado com sucesso!");break;
      case 'D': printf("\nDestroyer afundado com sucesso!");break;
      case 'R': printf("\nCarrier afundado com sucesso!");break;
      case 'B': printf("\nBattleship afundado com sucesso!");break;
      default:break;
    }
  }
}

void jogo_comecar(int tamanhocampo ,struct cell player1[tamanhocampo][tamanhocampo], struct cell player2[tamanhocampo][tamanhocampo])
{
  int pecas_player1=contar_pecas(tamanhocampo,player1);
  int pecas_player2=contar_pecas(tamanhocampo,player2);
  char x;
  int y;
  while(pecas_player1!=0 && pecas_player2!=0)
  {
    //PLAYER 1
    player_flag=0;
    printar_tabuleiro(tamanhocampo,player1);
    printf("\n\n Tua vez de atacar!");
    printf("\nSelecione as coordenadas.");
    printf("\n(Introduzir Letra) x:");
    scanf(" %c",&x);
    printf("(Introduzir Numero) y:");
    scanf("%d",&y);
    setvbuf(stdout, NULL, _IONBF, 0);
    if(*player2[y-1][alfabeto(x)].sh.peca=='1')
    {
      printf("\n Navio inimigo atingido!");
      player2[y-1][alfabeto(x)].sh.peca="2";
      pecas_player2--;
      barco_afundado(tamanhocampo,player2,player2[y-1][alfabeto(x)].sh.boat);
    }
    else {
      player2[y-1][alfabeto(x)].sh.peca="3";
      player2[y-1][alfabeto(x)].shot=1;
      printf("\n O tiro não atingiu nenhum barco inimigo!");
    }
    if(pecas_player2==0){break;}
    delay();
    system("clear");
    // PLAYER 2
    player_flag=1;
    printar_tabuleiro(tamanhocampo,player2);
    printf("\n\n Tua vez de atacar!");
    printf("\nSelecione as coordenadas.");
    printf("\n(Introduzir Letra) x:");
    scanf(" %c",&x);
    printf("(Introduzir Numero) y:");
    scanf("%d",&y);
    setvbuf(stdout, NULL, _IONBF, 0);
    if(*player1[y-1][alfabeto(x)].sh.peca=='1')
    {
      printf("\n Navio inimigo atingido!");
      player1[y-1][alfabeto(x)].sh.peca="2";
      pecas_player1--;
      barco_afundado(tamanhocampo,player1,player1[y-1][alfabeto(x)].sh.boat);
    }
    else {
      player1[y-1][alfabeto(x)].sh.peca="3";
      player1[y-1][alfabeto(x)].shot=1;
      printf("\n O tiro não atingiu nenhum barco inimigo!");
    }
    if(pecas_player1==0){break;}
    delay();
    system("clear");
  }
  if(pecas_player2==0)
  {
    vencedor(1);
  }
  if(pecas_player1==0)
  {
    vencedor(2);
  }
}

int fora_tabuleiro(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo],int x, int y,char boat )   // Algoritmo para determinar se peça está fora do mapa
{
  int contagem=0;
  char limite=alfabeto(tamanhocampo);
  char w='1';
  int varx=alfabeto(x)-2;
  int vary=y-3;
  int limitex=0;
  int limitey=0;
  if(varx<0)
  {
    limitex=varx;
    varx=0;
  }
  if(vary<=0)
  {
    limitey=vary;
    vary=0;
  }
  int flag=0;
  int resetx=varx;
  for(int i=0;i<5+limitey;i++)
  {
    for(int k=0;k<5+limitex;k++)
    {
      flag=0;
      if(varx<0){flag=1;}
      if(varx>=tamanhocampo){flag=1;}
      if(vary>=tamanhocampo){flag=1;}
      if(flag==0)
      {
        if(jogo[vary][varx].sh.peca!=NULL && jogo[vary][varx].sh.boat==boat)
        {
           contagem++;
        }
      }
      varx++;
    }
    varx=resetx;
    vary++;
  }
    //printf("\n\nCONTAGEM: %d\n\n",contagem);
  switch(boat)
  {
    case 'S': if(contagem!=3)return 0;break;
    case 'C': if(contagem!=6)return 0;break;
    case 'D': if(contagem!=5)return 0;break;
    case 'R': if(contagem!=4)return 0;break;
    case 'B': if(contagem!=5)return 0;break;
    default: return 1;break;
  }
}

void def_rotacao(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo],int x, int y,char boat,struct ship new )
{
  char limite=alfabeto(tamanhocampo);
  int varx=alfabeto(x)-2;
  int vary=y-3;
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      if(new.bitmap[i][k]=='1')
      {
        if(jogo[vary][varx].sh.peca=="1")
        {
          printf("\nErro! Esse local já possuia uma peça!");
          exit(0);
        }
        jogo[vary][varx].sh.peca="1";
        jogo[vary][varx].sh.boat=boat;
      }
      varx++;
    }
    varx=alfabeto(x)-2;
    vary++;
  }
}

void rotacao_0(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo],int x,int y,char boat)
{
  struct ship new;
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      new.bitmap[i][k]=barco.bitmap[i][k];
    }
  }
  def_rotacao(tamanhocampo,jogo,x,y,boat,new);
}

void rotacao_90(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo],int x,int y, char boat)
{
  struct ship new;
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      new.bitmap[i][k]=barco.bitmap[4-k][i];
    }
  }
  def_rotacao(tamanhocampo,jogo,x,y,boat,new);
}

void rotacao_180(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo],int x,int y, char boat)
{
  struct ship new;
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      new.bitmap[i][k]=barco.bitmap[4-i][k];
    }
  }
  def_rotacao(tamanhocampo,jogo,x,y,boat,new);
}

void rotacao_270(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo],int x,int y, char boat)
{
  struct ship new;
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      new.bitmap[i][k]=barco.bitmap[k][4-i];
    }
  }
  def_rotacao(tamanhocampo,jogo,x,y,boat,new);
}

void rotacao(int tamanhocampo, struct cell jogo[tamanhocampo][tamanhocampo],int x,int y, char boat)
{
  if(y<=0 || y>tamanhocampo || alfabeto(x)<0 || alfabeto(x)>tamanhocampo )
  {
    printf("Coordenadas não validas!");
    exit(0);
  }
  int rotacao;
  printf("\n Deseja efetuar alguma rotaçao? ");
  printf("\n Rotações disponiveis: 0 90 180 270.");
  printf("\n Rotação: ");
  scanf("%d",&rotacao);
  switch (rotacao)
  {
      case 0:rotacao_0(tamanhocampo,jogo,x,y,boat);
             printar_tabuleiro(tamanhocampo,jogo);
             break;
     case 90:rotacao_90(tamanhocampo,jogo,x,y,boat);
             printar_tabuleiro(tamanhocampo,jogo);
             break;
    case 180:rotacao_180(tamanhocampo,jogo,x,y,boat);
             printar_tabuleiro(tamanhocampo,jogo);
             break;
    case 270:rotacao_270(tamanhocampo,jogo,x,y,boat);
             printar_tabuleiro(tamanhocampo,jogo);
             break;
  }
}

void inserir_submarine(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  char boat='S';
  def_submarine();
  int y;
  char x;
  printf("\n\n Em que posição deseja inserir o Submarine?  (Coordenada X Y escolhida será o centro da peça)");
  printf("\n(Introduzir Letra) x:");
  scanf(" %c",&x);
  printf("(Introduzir Numero) y:");
  scanf("%d",&y);
  rotacao(tamanhocampo,jogo,x,y,boat);
  if(fora_tabuleiro(tamanhocampo,jogo,x,y,boat)==0)
  {
    printf("\nSubmarine colocado fora do mapa!\n");
    exit(0);
  }
}


void inserir_cruiser(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  char boat='C';
  def_cruiser();
  int y;
  char x;
  printf("\n\n Em que posição deseja inserir o Cruiser?  (Coordenada X Y escolhida será o centro da peça)");
  printf("\n(Introduzir Letra) x:");
  scanf(" %c",&x);
  printf("(Introduzir Numero) y:");
  scanf("%d",&y);
  rotacao(tamanhocampo,jogo,x,y,boat);
  if(fora_tabuleiro(tamanhocampo,jogo,x,y,boat)==0)
  {
    printf("\nCruiser colocado fora do mapa!\n");
    exit(0);
  }
}


void inserir_destroyer(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  char boat='D';
  def_destroyer();
  int y;
  char x;
  printf("\n\n Em que posição deseja inserir o Destroyer?  (Coordenada X Y escolhida será o centro da peça)");
  printf("\n(Introduzir Letra) x:");
  scanf(" %c",&x);
  printf("(Introduzir Numero) y:");
  scanf("%d",&y);
  rotacao(tamanhocampo,jogo,x,y,boat);
  if(fora_tabuleiro(tamanhocampo,jogo,x,y,boat)==0)
  {
    printf("\nDestroyer colocado fora do mapa!\n");
    exit(0);
  }
}

void inserir_carrier(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  char boat='R';
  def_carrier();
  int y;
  char x;
  printf("\n\n Em que posição deseja inserir o Carrier?  (Coordenada X Y escolhida será o centro da peça)");
  printf("\n(Introduzir Letra) x:");
  scanf(" %c",&x);
  printf("(Introduzir Numero) y:");
  scanf("%d",&y);
  rotacao(tamanhocampo,jogo,x,y,boat);
  if(fora_tabuleiro(tamanhocampo,jogo,x,y,boat)==0)
  {
    printf("\nCarrier colocado fora do mapa!\n");
    exit(0);
  }
}

void inserir_battleship(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  char boat='B';
  def_battleship();
  int y;
  char x;
  printf("\n\n Em que posição deseja inserir o Battleship?  (Coordenada X Y escolhida será o centro da peça)");
  printf("\n(Introduzir Letra) x:");
  scanf(" %c",&x);
  printf("(Introduzir Numero) y:");
  scanf("%d",&y);
  rotacao(tamanhocampo,jogo,x,y,boat);
  if(fora_tabuleiro(tamanhocampo,jogo,x,y,boat)==0)
  {
    printf("\nBattleship colocado fora do mapa!\n");
    exit(0);
  }
}


void opcao_manual(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  int x=0;
  char boat='-';
  system("clear");
  printf("\n\n\n\n");
  if(player_flag==0)
  {
  printf("                    PLAYER 1 \n");
  }
  if(player_flag==1)
  {
  printf("                    PLAYER 2 \n" );
  }
  printf("  ______________________________________________   \n");
  printf(" |         Seleção de peças manualmente         |  \n");
  printf(" |       irá começar em breves instantes        |  \n");
  printf(" |______________________________________________|  \n");
  delay();
  printf("\n\n");
  printar_tabuleiro(tamanhocampo,jogo);
  while(x<=maximo_pecas)
  {
    x+=3;
    if(x>maximo_pecas)
    break;
    inserir_submarine(tamanhocampo,jogo);
    x+=6;
    if(x>maximo_pecas)
    break;
    inserir_cruiser(tamanhocampo,jogo);
    x+=5;
    if(x>maximo_pecas)
    break;
    inserir_destroyer(tamanhocampo,jogo);
    x+=4;
    if(x>maximo_pecas)
    break;
    inserir_carrier(tamanhocampo,jogo);
    x+=6;
    if(x>maximo_pecas)
    break;
    inserir_battleship(tamanhocampo,jogo);
}
  setvbuf(stdout, NULL, _IONBF, 0);
  printf("\n\nTodos os barcos inseridos com sucesso.");
}


void aleatorio_rotacao(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo],int x,int y, char boat)
{
  int numero = (rand()%(4))+1; // dois numeros randoms
  if(numero==1)
  {
    rotacao_0(tamanhocampo,jogo,x,y,boat);
  }
  if(numero==2)
  {
    rotacao_90(tamanhocampo,jogo,x,y,boat);
  }
  if(numero==3)
  {
    rotacao_180(tamanhocampo,jogo,x,y,boat);
  }
  if(numero==4)
  {
    rotacao_270(tamanhocampo,jogo,x,y,boat);
  }
}

int s2=0;
int contagemy=0;
int contagemc=0;
int c2=0;
int contagemd=0;
int d2=0;

void reset_val()
{
  s2=0;
  contagemy=0;
  contagemc=0;
  c2=0;
  contagemd=0;
  d2=0;
  contagem_random=0;
  flag_random=0;
}

void random_rotacao(int tamanhocampo, struct cell jogo[tamanhocampo][tamanhocampo],char boat)
{
  char x;
  int x1,y1;
  int y;
  if(contagem_random>=5)
  {
    flag_random=1;
  }
  switch(boat)
  {
    case 'S':
              x1=aleatorio(2,tamanhocampo-2);
              y1=aleatorio(2,tamanhocampo-2);
             while(contagem_false(x1,y1)==0)
             {
               y1=aleatorio(2,tamanhocampo-2);
             }
             x=alfabeto_v2(x1);y=y1;
             preencher(x1,y);
             aleatorio_rotacao(tamanhocampo,jogo,x,y,boat);
             break;
    case 'C':
            x1=aleatorio(2,tamanhocampo-2);
            y1=aleatorio(2,tamanhocampo-2);
            while(contagem_false(x1,y1)==0)
            {
              y1=aleatorio(2,tamanhocampo-2);
            }
            x=alfabeto_v2(x1);y=y1;
            preencher(x1,y);
            aleatorio_rotacao(tamanhocampo,jogo,x,y,boat);
            break;
    case 'D':
            x1=aleatorio(3,tamanhocampo-3);
            y1=aleatorio(3,tamanhocampo-3);
            while(contagem_false(x1,y1)==0)
            {
              y1=aleatorio(2,tamanhocampo-2);
            }
            x=alfabeto_v2(x1);y=y1;
            preencher(x1,y);
            aleatorio_rotacao(tamanhocampo,jogo,x,y,boat);
            break;
   case 'R':
            x1=aleatorio(2,tamanhocampo-2);
            y1=aleatorio(2,tamanhocampo-2);
            while(contagem_false(x1,y1)==0)
            {
              y1=aleatorio(2,tamanhocampo-2);
            }
            x=alfabeto_v2(x1);y=y1;
            preencher(x1,y);
            aleatorio_rotacao(tamanhocampo,jogo,x,y,boat);
            break;
  case 'B':
            x1=aleatorio(2,tamanhocampo-2);
            y1=aleatorio(2,tamanhocampo-2);
            while(contagem_false(x1,y1)==0)
            {
              y1=aleatorio(2,tamanhocampo-2);
            }
            x=alfabeto_v2(x1);y=y1;
            preencher(x1,y);
            aleatorio_rotacao(tamanhocampo,jogo,x,y,boat);
            break;
  }
}
void opcao_random(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo])
{
  system("clear");
  printf("\n\n\n\n");
  if(player_flag==0)
  {
  printf("                    PLAYER 1 \n");
  }
  if(player_flag==1)
  {
  printf("                    PLAYER 2 \n" );
  }
  printf("  ______________________________________________   \n");
  printf(" |      Seleção de peças de automaticamente     |  \n");
  printf(" |       irá começar em breves instantes        |  \n");
  printf(" |______________________________________________|  \n");
  delay();
  printf("\n\n");
  int x=0;
  char boat='-';
  while(x<maximo_pecas)
  {
    x+=3;
    if(x>maximo_pecas)
    break;

    def_submarine();
    boat='S';
    random_rotacao(tamanhocampo,jogo,boat);

    x+=6;
    if(x>maximo_pecas)
    break;

    def_cruiser();
    boat='C';
    random_rotacao(tamanhocampo,jogo,boat);

    x+=5;
    if(x>maximo_pecas)
    break;

    def_destroyer();
    boat='D';
    random_rotacao(tamanhocampo,jogo,boat);

    x+=4;
    if(x>maximo_pecas)
    break;

    def_carrier();
    boat='R';
    random_rotacao(tamanhocampo,jogo,boat);

    x+=6;
    if(x>maximo_pecas)
    break;

    def_battleship();
    boat='B';
    random_rotacao(tamanhocampo,jogo,boat);
}
}

void novojogo()
  {
    int tamanhocampo;
    char organizacao[10];
    system("clear");
    printf("  _____________________________________________  \n");
    printf(" |    _   _  ___ ___      __  __     ___  _    | \n");
    printf(" |   |_) |_|  |   |  |   |_  (_  |_|  |  |_)   | \n");
    printf(" |   |_) | |  |   |  |__ |__ __) | | _|_ |     | \n");
    printf(" |_____________________________________________| \n");
    printf("\n");
    printf("Selecione o tamanho do campo de batalha: ");
    scanf("%d",&tamanhocampo);
    struct cell jogo_player1[tamanhocampo][tamanhocampo];
    struct cell jogo_player2[tamanhocampo][tamanhocampo];
    maximo_pecas=(tamanhocampo*tamanhocampo)/25;
    definir(tamanhocampo,jogo_player1);
    definir(tamanhocampo,jogo_player2);
    if(tamanhocampo<20 || tamanhocampo>40)
      {
        printf("\n Erro! O tamanho do campo de batalha tem que ser entre 20 e 40!\n");
        exit(1);
      }

      printf("\n");
      printf("Poderá organizar os barcos de maneira Aleatoria (Random) ou inserir manualmente (Manual).\n");
      printf("Qual das maneiras prefere ? ");
      scanf("%s",organizacao);
      if(strcmp(organizacao,"Manual")==0 || strcmp(organizacao,"manual")==0 || strcmp(organizacao,"MANUAL")==0)   // palavras aceites : manual Manual MANUAL
        {
          opcao_manual(tamanhocampo,jogo_player1);
          delay();
          player_flag=1;
          opcao_manual(tamanhocampo,jogo_player2);
          play_screen();
          jogo_comecar(tamanhocampo,jogo_player1,jogo_player2);
        }
      else if(strcmp(organizacao,"Random")==0 || strcmp(organizacao,"random")==0 || strcmp(organizacao,"RANDOM")==0)  // palavras aceites: Random RANDOM random
        {
          reset_val();
          opcao_random(tamanhocampo,jogo_player1);
          printar_tabuleiro(tamanhocampo,jogo_player1);
          delay();
          reset_val();
          limpar_random();
          player_flag=1;
          opcao_random(tamanhocampo,jogo_player2);
          printar_tabuleiro(tamanhocampo,jogo_player2);
          delay();
          play_screen();
          jogo_comecar(tamanhocampo,jogo_player1,jogo_player2);
        }
        else {
          printf("\nNão foi possivel reconhecer a maneira de organização dos barcos.");
          printf("\nPalavras aceites: manual , random , Manual, Random, RANDOM, MANUAL");
          printf("\n");
        }
  }


void sair()
{
  system("clear");
  printf("  ______________________________________________   \n");
  printf(" |                                              |  \n");
  printf(" |            Obrigado por ter jogado           |  \n");
  printf(" |______________________________________________|  \n");
  exit(1);
}

void regras()
{
   int menu;
   system("clear");
   printf("  ______________________________________________   \n");
   printf(" |                                              |  \n");
   printf(" |                   Regras                     |  \n");
   printf(" |                                              |  \n");
   printf(" |1. Cada jogador posiciona os seus barcos no   |  \n");
   printf(" |tabuleiro de modo que não se toquem.          |  \n");
   printf(" |                                              |  \n");
   printf(" |2. À vez, cada jogador dispára um tiro, indi- |  \n");
   printf(" |cando as coordenadas do alvo através do número|  \n");
   printf(" |da linha e da letra da coluna que definem o   |  \n");
   printf(" |local.                                        |  \n");
   printf(" |                                              |  \n");
   printf(" |3. Se acertar num barco do oponente, será in- |  \n");
   printf(" |formado de qual barco foi atingido, e se este |  \n");
   printf(" |afundou.                                      |  \n");
   printf(" |                                              |  \n");
   printf(" |4. Um barco afunda quando todas as células que|  \n");
   printf(" |o formam são atingidas.                       |  \n");
   printf(" |                                              |  \n");
   printf(" |5. O jogo termina quando um jogador afundar   |  \n");
   printf(" |todos os barcos do oponente.                  |  \n");
   printf(" |______________________________________________|  \n");
   printf("\n\nPara voltar ao início pressione 1\n");
   printf("Para encerrar o programa pressione 0\n");
   scanf("%d",&menu);
   if(menu==1)
   {
     main();
   }
   if(menu==0)
   {
     sair();
   }
}

void intro()
{
  system("clear");
  int valormenu;
  printf("  _____________________________________________  \n");
  printf(" |    _   _  ___ ___      __  __     ___  _    | \n");
  printf(" |   |_) |_|  |   |  |   |_  (_  |_|  |  |_)   | \n");
  printf(" |   |_) | |  |   |  |__ |__ __) | | _|_ |     | \n");
  printf(" |_____________________________________________| \n");
  printf("\n");
  printf(" 1- Começar novo jogo                           \n");
  printf(" 2- Regras                                      \n");
  printf(" 3- Sair                                        \n");
  printf("\n");
  printf("Selecione uma opção: ");
  scanf("%d", &valormenu                                     );
  switch (valormenu)
    {
    case 1:
      novojogo();
      break;
    case 2:
      regras();
      break;
    case 3:
      sair();
      break;
    }
}

void comecar_random() {
    srand(time(NULL));
}

void main()
{
  comecar_random();
  intro();
}

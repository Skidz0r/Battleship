#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include "barcos.h"

int search_flag=0;
int inserir_flag=0;
int size64=0;

struct node {
    int *x;
    int *y;
    struct node *children[4];
    struct cell *cell;
};

 struct quadtree {
    int size;
    struct node *root;
};


int vigia;

const char* first_quad;
const char* pr_compare(struct node *node , int x , int y)
{
  if(*node->x==x && *node->y==y){printf(" SE ");return "SE";}
  else if(*node->x>x && *node->y<=y){printf(" SW ");return "SW";}
  else if(*node->x>x && *node->y>y){printf(" NW ");return "NW";}
  else if(*node->x<=x && *node->y>y){printf(" NE ");return "NE";}
  else if(*node->x<=x && *node->y<=y){printf(" SE ");return "SE";}
}


int has_children(struct node *node)
{
  int c=0;
  for(int i=0;i<4;i++)
  {
    if(node->children[i]!=NULL)
    {
      return 1;
    }
  }
  return 0;
}

void make_childs_root(struct node *node)
{
  for(int i=0;i<4;i++)
  {
    node->children[i]=malloc(10*sizeof(node->children[i]));
    node->children[i]->cell=malloc(10*sizeof(node->children[i]->cell));
    node->children[i]->cell->sh.peca=malloc(10*sizeof(int));
    node->children[i]->x=malloc(sizeof(int));
    node->children[i]->y=malloc(sizeof(int));
  }
  if(size64==0)
  {
  *node->children[0]->x=8;*node->children[0]->y=8;
  *node->children[1]->x=24;*node->children[1]->y=8;
  *node->children[2]->x=8;*node->children[2]->y=24;
  *node->children[3]->x=24;*node->children[3]->y=24;
}
  else if(size64==1)
  {
  *node->children[0]->x=16;*node->children[0]->y=16;
  *node->children[1]->x=48;*node->children[1]->y=16;
  *node->children[2]->x=16;*node->children[2]->y=48;
  *node->children[3]->x=48;*node->children[3]->y=48;
  }
}

void make_childs_null(struct node *node)
{
  int decrease=0;
  if(size64==0){
  if(inserir_flag==0){decrease=4;}
  if(inserir_flag==1){decrease=2;}
  if(inserir_flag==2){decrease=1;}}
  else if(size64==1)
  {
    if(inserir_flag==0){decrease=8;}
    if(inserir_flag==1){decrease=4;}
    if(inserir_flag==2){decrease=2;}
    if(inserir_flag==3){decrease=1;}
  }
  for(int i=0;i<4;i++)
  {
    node->children[i]=malloc(10*sizeof(node->children[i]));
    node->children[i]->cell=malloc(10*sizeof(node->children[i]->cell));
    node->children[i]->cell->sh.peca=malloc(10*sizeof(int));
    node->children[i]->x=malloc(sizeof(int));
    node->children[i]->y=malloc(sizeof(int));
    if(i==0)
    {
      *node->children[i]->x=*node->x-decrease;
      *node->children[i]->y=*node->y-decrease;
    }
    else if(i==1)
    {
      *node->children[i]->x=*node->x+decrease;
      *node->children[i]->y=*node->y-decrease;
    }
    else if(i==2)
    {
      *node->children[i]->x=*node->x-decrease;
      *node->children[i]->y=*node->y+decrease;
    }
    else if(i==3)
    {
      *node->children[i]->x=*node->x+decrease;
      *node->children[i]->y=*node->y+decrease;
    }
  }
}


void definir_quadtree(int tamanhocampo,struct cell jogo[tamanhocampo][tamanhocampo] )     // Colocar tabuleiro de jogo todo a 0.
{
  for(int i=0;i<tamanhocampo;i++)
  {
    for(int k=0;k<tamanhocampo;k++)
    {
      jogo[i][k].sh.peca="0";
    }
  }
  for(int i=0;i<40;i++)
  {
    for(int k=0;k<40;k++)
    {
        jogo[i][k].sh.peca="1";
    }
  }
}

void def_root( struct quadtree *quadtree)
{
  if(quadtree->size==32)
  {
  *quadtree->root->x=16;
  *quadtree->root->y=16;
  quadtree->root->cell->sh.peca="0";
  make_childs_root(quadtree->root);
}
  else if(quadtree->size==64)
  {
  *quadtree->root->x=32;
  *quadtree->root->y=32;
  quadtree->root->cell->sh.peca="0";
    size64=1;
  make_childs_root(quadtree->root);
}

}



const char* search(struct node *node, int x , int y, int peca)   // Search algorithm
{
  if(*node->x==x && *node->y==y && atoi(node->cell->sh.peca)==peca )
    {
      //printf(" search:%s",node->cell->sh.peca);
      search_flag=1;
      return node->cell->sh.peca;
    }
  for(int i=0;i<4;i++)
  {
    if(node->children[i]!=NULL)
    {
      if(*node->children[i]->x==x && *node->children[i]->y==y && atoi(node->children[i]->cell->sh.peca)==peca )
      {
        //printf(" search:%s",node->children[i]->cell->sh.peca);
        search_flag=1;
        return node->children[i]->cell->sh.peca;
      }
       search(node->children[i],x,y,peca);
    }
  }
  //return "0";
}



struct node * create_node(struct cell cell,int x, int y)
{
  struct node *node = malloc(10*sizeof(struct node));
  node->cell = malloc(10*sizeof(struct node));
  node->x=malloc(sizeof(int));node->y=malloc(sizeof(int));
  node->cell->sh.peca=malloc(10*sizeof(int));
  *node->x=x;
  *node->y=y;
  node->cell->sh.peca=cell.sh.peca;
  node->cell->sh.boat= cell.sh.boat;
  node->cell->shot=cell.shot;
  return node;
}

void inserir_no(struct node* root, struct node* node)
{
  if(vigia==5 && size64==0 || vigia==6 && size64==1)
  {
    printf("x:%d y:%d ",*node->x,*node->y);
  }
  int quadrante; // int quadrante nao significa (Exatamente) qual o quadrante mas sim qual o children[k].
  const char *s=pr_compare(root,*node->x,*node->y);
  if(s=="SW"){quadrante=2;}
  else if(s=="NW"){quadrante=0;}
  else if(s=="SE"){quadrante=3;}
  else if(s=="NE"){quadrante=1;}
  else return;
  /*  if(s=="NW"){first_quad="SE";}
    if(s=="NE"){first_quad="SW";}
    if(s=="SW"){first_quad="NE";}
    if(s=="SE"){first_quad="NW";}*/
  if(root->children[quadrante]==NULL)
  {
    make_childs_null(root);
    inserir_flag++;
    if(vigia==1)
    {
          root->children[quadrante]=malloc(10*sizeof(struct node));
          root->children[quadrante]->x=malloc(10*sizeof(int));
          root->children[quadrante]->y=malloc(10*sizeof(int));
          root->children[quadrante]->cell=malloc(10*sizeof(struct node));
          root->children[quadrante]->cell->sh.peca=malloc(10*sizeof(int));
          root->children[quadrante]->x=node->x;
          root->children[quadrante]->y=node->y;
          root->children[quadrante]->cell->sh.peca=node->cell->sh.peca;
          root->children[quadrante]->cell->sh.boat=node->cell->sh.boat;
          root->children[quadrante]->cell->shot=node->cell->shot;
          printf("\n");
          //root->children[quadrante]=node;
         //printf("%s",root->children[quadrante]->cell->sh.peca);
          return;
    }
}
if(size64==0)
{
if(vigia==3)
{
  for(int i=0;i<4;i++)
  {
    if(i==0){*root->children[i]->x=*root->x-2;*root->children[i]->y=*root->y-2;}
    if(i==1){*root->children[i]->x=*root->x+2;*root->children[i]->y=*root->y-2;}
    if(i==2){*root->children[i]->x=*root->x-2;*root->children[i]->y=*root->y+2;}
    if(i==3){*root->children[i]->x=*root->x+2;*root->children[i]->y=*root->y+2;}
  }
}
if(vigia==2)
{
  for(int i=0;i<4;i++)
  {
    if(i==0){*root->children[i]->x=*root->x-1;*root->children[i]->y=*root->y-1;}
    if(i==1){*root->children[i]->x=*root->x+1;*root->children[i]->y=*root->y-1;}
    if(i==2){*root->children[i]->x=*root->x-1;*root->children[i]->y=*root->y+1;}
    if(i==3){*root->children[i]->x=*root->x+1;*root->children[i]->y=*root->y+1;}
  }
 }
}

if(size64==1)
{
if(vigia==4)
{
  for(int i=0;i<4;i++)
  {
    if(i==0){*root->children[i]->x=*root->x-4;*root->children[i]->y=*root->y-4;}
    if(i==1){*root->children[i]->x=*root->x+4;*root->children[i]->y=*root->y-4;}
    if(i==2){*root->children[i]->x=*root->x-4;*root->children[i]->y=*root->y+4;}
    if(i==3){*root->children[i]->x=*root->x+4;*root->children[i]->y=*root->y+4;}
  }
}
if(vigia==3)
{
  for(int i=0;i<4;i++)
  {
    if(i==0){*root->children[i]->x=*root->x-2;*root->children[i]->y=*root->y-2;}
    if(i==1){*root->children[i]->x=*root->x+2;*root->children[i]->y=*root->y-2;}
    if(i==2){*root->children[i]->x=*root->x-2;*root->children[i]->y=*root->y+2;}
    if(i==3){*root->children[i]->x=*root->x+2;*root->children[i]->y=*root->y+2;}
  }
 }
 if(vigia==2)
 {
   for(int i=0;i<4;i++)
   {
     if(i==0){*root->children[i]->x=*root->x-1;*root->children[i]->y=*root->y-1;}
     if(i==1){*root->children[i]->x=*root->x+1;*root->children[i]->y=*root->y-1;}
     if(i==2){*root->children[i]->x=*root->x-1;*root->children[i]->y=*root->y+1;}
     if(i==3){*root->children[i]->x=*root->x+1;*root->children[i]->y=*root->y+1;}
   }
  }
}

  if(vigia==1)
  {
    for(int i=0;i<4;i++)
    {
      if(root->children[i]->cell->sh.peca!="0" && root->children[i]->cell->sh.peca!="1" && root->children[i]->cell->sh.peca!="2" && root->children[i]->cell->sh.peca!="3" )
      {
        printf("\n");
        root->children[i]=malloc(10*sizeof(struct node));
        root->children[i]->x=malloc(10*sizeof(int));
        root->children[i]->y=malloc(10*sizeof(int));
        root->children[i]->cell=malloc(10*sizeof(struct node));
        root->children[i]->cell->sh.peca=malloc(10*sizeof(int));
        root->children[i]->x=node->x;
        root->children[i]->y=node->y;
        root->children[i]->cell->sh.peca=node->cell->sh.peca;
        root->children[i]->cell->sh.boat=node->cell->sh.boat;
        root->children[i]->cell->shot=node->cell->shot;
        //root->children[quadrante]=node;
      //  printf("%s",root->children[quadrante]->cell->sh.peca);
        return;
      }
    }
  }
  vigia--;
   return inserir_no(root->children[quadrante],node);
}

void quadtree_add(struct quadtree *quadtree, struct node *node)
{
  if(quadtree->root->cell->sh.peca==node->cell->sh.peca)
  {
    return ;
  }
  if(size64==0){vigia=5;}
  if(size64==1){vigia=6;}
  inserir_flag=0;
  first_quad="";
  inserir_no(quadtree->root,node);
}

void quadtree_transf(int tamanhocampo,struct quadtree *quadtree , struct cell jogo_player1[tamanhocampo][tamanhocampo])
{
  for(int i=0;i<tamanhocampo;i++)
  {
    for(int k=0;k<tamanhocampo;k++)
    {
      struct node *no=malloc(10*sizeof(struct node));
      no->cell=malloc(10*sizeof(struct node));
      no->x=malloc(sizeof(int));no->y=malloc(sizeof(int));
      no=create_node(jogo_player1[i][k],i,k);
      quadtree_add(quadtree,no);
    }
  }
}

void print_tabuleiro_quadtree(struct quadtree *quadtree,int tamanhocampo)
{
  for(int i=0;i<tamanhocampo;i++)
  {
    for(int k=0;k<tamanhocampo;k++)
    {
      for(int j=3;j>=0;j--)
      {
        search_flag=0;
        search(quadtree->root,i,k,j);
        if(search_flag==1)
        {
          printf("%d",j);
          break;
        }
        if(j==0)printf("0");
      }
    }
    printf("\n");
  }
}

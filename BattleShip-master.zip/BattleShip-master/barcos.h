extern void def_submarine();
extern void def_cruiser();
extern void def_destroyer();
extern void def_carrier();
extern void def_battleship();
extern void reset();


struct ship{
  char bitmap[5][5];
};

struct ship barco;

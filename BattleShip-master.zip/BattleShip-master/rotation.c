#include <stdio.h>

struct ship{
  char bitmap[5][5];
};



void rotation(int k, struct ship barco){
  struct ship new;

  // definir ship new com tudo a '0'
  for(int i=0;i<5;i++){
    for(int k=0;k<5;k++){
      new.bitmap[i][k]='0';
    }
  }


  //rotação 90 graus
  if(k==90){
    for(int i=0;i<5;i++){
      for(int j=0;j<5;j++){
        new.bitmap[i][j]=barco.bitmap[4-j][i];
      }
    }
  }
  else if(k==180){
    for(int i=0;i<5;i++){
      for(int j=0;j<5;j++){
        new.bitmap[i][j]=barco.bitmap[4-i][j];
      }
    }
  }

  else if(k==270){
    for(int i=0;i<5;i++){
      for(int j=0;j<5;j++){
        new.bitmap[i][j]=barco.bitmap[j][4-i];
      }
    }
  }

//printar ship com rotation
  for(int i=0;i<5;i++){
    for(int k=0;k<5;k++){
      printf("%c",new.bitmap[i][k]);
    }
  }

}


int main(){
  struct ship barco;
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      barco.bitmap[i][k]='0';
    }
  }
  barco.bitmap[0][1]='1';                          // 0 0 0 0 0
  barco.bitmap[0][2]='1';                          // 0 0 0 0 0
  barco.bitmap[0][3]='1';


  rotation(90,barco);

}

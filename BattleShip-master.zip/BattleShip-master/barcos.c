#include <stdio.h>
#include "barcos.h"

void reset(struct ship barco)
{
  for(int i=0;i<5;i++)
  {
    for(int k=5;k<5;k++)
    {
      barco.bitmap[i][k]='0';
    }
  }
}

void def_submarine()
{
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      barco.bitmap[i][k]='0';                      // 0 0 0 0 0
    }                                              // 0 0 0 0 0
  }                                                // 0 1 1 1 0
  barco.bitmap[2][1]='1';                          // 0 0 0 0 0
  barco.bitmap[2][2]='1';                          // 0 0 0 0 0
  barco.bitmap[2][3]='1';
}


void def_cruiser()
{
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      barco.bitmap[i][k]='0';
    }
  }
  barco.bitmap[1][1]='1';
  barco.bitmap[1][3]='1';
  barco.bitmap[2][1]='1';
  barco.bitmap[2][2]='1';
  barco.bitmap[3][2]='1';
  barco.bitmap[2][3]='1';

}


void def_destroyer()
{
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      barco.bitmap[i][k]='0';
    }
  }
  barco.bitmap[0][2]='1';
  barco.bitmap[0][3]='1';
  barco.bitmap[1][2]='1';
  barco.bitmap[2][2]='1';
  barco.bitmap[3][2]='1';
}


void def_carrier()
{
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      barco.bitmap[i][k]='0';
    }
  }
  barco.bitmap[2][1]='1';
  barco.bitmap[2][2]='1';
  barco.bitmap[2][3]='1';
  barco.bitmap[3][2]='1';

}

void def_battleship()
{
  for(int i=0;i<5;i++)
  {
    for(int k=0;k<5;k++)
    {
      barco.bitmap[i][k]='0';
    }
  }
  barco.bitmap[1][1]='1';
  barco.bitmap[1][3]='1';
  barco.bitmap[2][1]='1';
  barco.bitmap[2][2]='1';
  barco.bitmap[2][3]='1';
}

void regras(){
   int menu;
   system("clear");
   printf("  ______________________________________________   \n");
   printf(" |                                              |  \n");
   printf(" |                   Regras                     |  \n");
   printf(" |                                              |  \n");
   printf(" |1. Cada jogador posiciona os seus barcos no   |  \n");
   printf(" |tabuleiro de modo que não se toquem.          |  \n");
   printf(" |                                              |  \n");
   printf(" |2. À vez, cada jogador dispára um tiro, indi- |  \n");
   printf(" |cando as coordenadas do alvo através do número|  \n");
   printf(" |da linha e da letra da coluna que definem o   |  \n");
   printf(" |local.                                        |  \n");
   printf(" |                                              |  \n");
   printf(" |3. Se acertar num barco do oponente, será in- |  \n");
   printf(" |formado de qual barco foi atingido, e se este |  \n");
   printf(" |afundou.                                      |  \n");
   printf(" |                                              |  \n");
   printf(" |4. Um barco afunda quando todas as células que|  \n");
   printf(" |o formam são atingidas.                       |  \n");
   printf(" |                                              |  \n");
   printf(" |5. O jogo termina quando um jogador afundar   |  \n");
   printf(" |todos os barcos do oponente.                  |  \n");
   printf(" |______________________________________________|  \n");
   printf("\n\n\n\nPara voltar ao início pressione 1:\n");
   scanf("%d",&menu);
   if(menu==1) intro();
 }
